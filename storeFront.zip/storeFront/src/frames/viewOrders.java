package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import DBConn.DbConn;
import DBConn.DbUtils;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;


public class viewOrders extends JFrame {

	private JPanel contentPane;
	private static JTable tblViewOrders;

	/**
	 * Launch the application.
	 */
	//public static void main(String[] args) {
		//EventQueue.invokeLater(new Runnable() {
			//public void run() {
				//try {
					//viewOrders frame = new viewOrders();
					//frame.setVisible(true);
				//} catch (Exception e) {
				//	e.printStackTrace();
				//}
			//}
		//});
		
	
	//}
    
	
	/**
	 * Create the frame.
	 */
	public viewOrders() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 621, 416);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(161, 152, 334, 191);
		contentPane.add(scrollPane);
		
		tblViewOrders = new JTable();
		scrollPane.setViewportView(tblViewOrders);
		
		populateTable();
		//create the table
		tblViewOrders.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Order Name", "New column", "Orded Date"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnDelete = new JButton("Delete");
	
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					//find the selected row and order id
					int row = tblViewOrders.getSelectedRow();
					Object cell =  tblViewOrders.getModel().getValueAt(row, 0);
					
					//query to delete from database where ORDERID = selected row id
					String query = "DELETE FROM ORDERS WHERE ORDERID =" + cell;
					String query2 = "DELETE FROM DELIVERY WHERE ORDERID = " + cell;
					
					//connect with the database
					String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
			         String uName = "user";
			         String uPass = "pass";
			         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
			         Connection con = DriverManager.getConnection(host, uName, uPass);
			         
					PreparedStatement pst = con.prepareStatement(query);
					pst.execute();

					PreparedStatement pst2 = con.prepareStatement(query2);
					
					pst2.execute();

					
					//message to the user that the row have successfully deleted
					JOptionPane.showMessageDialog(null, "Data Deleted");
					
					
					
				}
				catch (Exception e1) {
					// TODO: handle exception
					e1.printStackTrace();
				}
				
				populateTable();
			}
		});
		btnDelete.setBounds(290, 89, 89, 23);
		contentPane.add(btnDelete);
		
		JButton btnShowinfo = new JButton("Show order info");
		btnShowinfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//find the selected row and order id
				int row = tblViewOrders.getSelectedRow();
				Object cell = tblViewOrders.getModel().getValueAt(row, 0);
			
				dispose();
				new orderInfo(cell).setVisible(true);
				frames.orderInfo.populateTable();
			}

			
		});
		
		
		btnShowinfo.setBounds(169, 89, 111, 23);
		contentPane.add(btnShowinfo);
		
		//return to manager options
		JButton btnBackToManager = new JButton("Manager options");
		btnBackToManager.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
					dispose();
					JFrame ManagerOptions = new SalesView();
					ManagerOptions.setVisible(true);
			}
		});
		btnBackToManager.setBounds(483, 11, 122, 23);
		contentPane.add(btnBackToManager);
	}
	
	
	public static void populateTable()
	{
		
		//Connect to database and make the query
		ResultSet rs = DbConn.connectToDB(" SELECT ORDERID,DATE,ORDERNAME FROM ORDERS WHERE CONFIRM = " + 0);
			
		//populate the table
		try {
			while(rs.next()) {
				tblViewOrders.setModel(DbUtils.resultSetToTableModel(rs));
			
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}
	
}
