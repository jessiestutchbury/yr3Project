package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DBConn.DbConn;
import DBConn.DbUtils;

import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;

public class orderInfo extends JFrame {

	private JPanel contentPane;
	private static 	Object id;
	private static JTable tblViewInfo;
	private JButton btnHelp;
	private JButton btnUpdate;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					orderInfo frame = new orderInfo(id);
					frame.setVisible(true);
					populateTable();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	static void populateTable() {
		
		// TODO Auto-generated method stub
		
		//Connect to database and make the query
		ResultSet rs = DbConn.connectToDB("SELECT * FROM DELIVERY WHERE ORDERID = " + id);
		
		//populate the table
		try {
			while(rs.next()) {
				tblViewInfo.setModel(DbUtils.resultSetToTableModel(rs));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}

	/**
	 * Create the frame.
	 */
	
	public orderInfo(Object cell) {
		
         id =  cell;
         System.out.println(id);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		tblViewInfo = new JTable();
		tblViewInfo.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblViewInfo.setBounds(68, 141, 300, 95);
		getContentPane().add(tblViewInfo);
		
		JButton btnDeleteAproduct = new JButton("Delete a product");
		btnDeleteAproduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDeleteAproduct.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				
				
				try {
					//find the selected row and DELIVERY_ID
					int row = tblViewInfo.getSelectedRow();
					Integer cell = (Integer) tblViewInfo.getModel().getValueAt(row, 0);
					
					//query to delete from database where DELIVERY_ID = selected row id
					
					String query = " DELETE FROM DELIVERY WHERE DELIVERY_ID = " + cell;
					
					//connect with the database
					String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
			         String uName = "user";
			         String uPass = "pass";
			         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
			         Connection con = DriverManager.getConnection(host, uName, uPass);
			         
					PreparedStatement pst = con.prepareStatement(query);
					pst.execute();
					pst.close();
				
					
					//message to the user that the row have successfully deleted
					JOptionPane.showMessageDialog(null, "Data Deleted");
					
					
			}
				 catch (Exception e) {
						e.printStackTrace();
					}
				populateTable();
				
		}});
		
		btnDeleteAproduct.setBounds(252, 92, 116, 23);
		getContentPane().add(btnDeleteAproduct);
		
		//help the user with some tips
		btnHelp = new JButton("HELP");
		btnHelp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, "To delete a product from the list you have to select it first and then press the Delete button" +"\n" + "The same applies for all the options that change the table" );
			}
		});
		btnHelp.setBounds(355, 45, 80, 23);
		contentPane.add(btnHelp);
		
		btnUpdate = new JButton("Update Product");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				int row = tblViewInfo.getSelectedRow();
				Integer id =  (Integer) tblViewInfo.getModel().getValueAt(row, 0);
				Integer product = (Integer) tblViewInfo.getModel().getValueAt(row, 1);
				Integer quantity_ordered =  (Integer) tblViewInfo.getModel().getValueAt(row, 2);
				//Object order_id = (String) tblViewInfo.getModel().getValueAt(row, 3);
				System.out.print(id );
				String query = "UPDATE DELIVERY SET PRODUCT_ID = ? ," + " QUANTITY_ORDERED = ? "  + " WHERE DELIVERY_ID = " + id;
                

				//connect with the database
				String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
		         String uName = "user";
		         String uPass = "pass";
		         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
		         Connection con = DriverManager.getConnection(host, uName, uPass);
		         
		         PreparedStatement pstmt = con.prepareStatement(query);
		         
		         pstmt.setInt(1,  product);
		         pstmt.setInt(2,  quantity_ordered);
		      
		         pstmt.executeUpdate();
					JOptionPane.showMessageDialog(null, " Success");
		         
			}

				 catch (Exception e1) {
						e1.printStackTrace();
					}
				populateTable();
				
			}
		});
		btnUpdate.setBounds(104, 92, 116, 23);
		contentPane.add(btnUpdate);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				JFrame viewOrders = new viewOrders();
				((viewOrders) viewOrders).populateTable();
				viewOrders.setVisible(true);
			}
		});
		btnBack.setBounds(354, 11, 80, 23);
		contentPane.add(btnBack);
	}
}
