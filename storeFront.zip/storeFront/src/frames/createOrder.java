package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DBConn.DbConn;
import DBConn.DbUtils;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.util.Date;


public class createOrder extends JFrame {

	private JPanel contentPane;
	private static JTable tblProducts;
	private JTextField txtproductName;
	private JTable tblSelected;
	private JButton btnInsert;
	private static Integer countrow; // it will count the rows that are used in the tblSelected


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					createOrder frame = new createOrder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
			}
			}
		});
		
		
	}

	/**
	 * Create the frame.
	 */
	public createOrder() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 673, 377);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		populateTable();
		countrow = 0;
		JButton btncretaOrder = new JButton("Create Order");
		btncretaOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
					//find the selected row and PRODUCT_ID
					
			
				
					
				    int selectedcount = tblSelected.getRowCount();				
					String name =  txtproductName.getText();
					
					//check if the order name is set
					if (name.equals(null) || name.trim().isEmpty() || selectedcount == 0)
						//check that a product is been selected 
				
					{
						JOptionPane.showMessageDialog(null, "Ender oder name, or select a product to order");}
					
					else {
					
					try {
						
						String query = "INSERT INTO ORDERS (DATE, ORDERNAME ,CONFIRM ) VALUES (?,?,?);";
						
						
						
						 String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
						  String uName = "user";
					         String uPass = "pass";
					         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
					         Connection con = DriverManager.getConnection(host, uName, uPass);
						   
					         PreparedStatement pstmt = con.prepareStatement(query);					         
					         pstmt.setDate(1, new java.sql.Date(new java.util.Date().getTime()));			
					         pstmt.setString(2, name);	
					         pstmt.setInt(3, 0);
					         pstmt.executeUpdate();	     
					         pstmt.close();
				
				
						
						
						String query2 = "SELECT ORDERID, ORDERNAME FROM ORDERS " ;

					         
					         PreparedStatement pstmt2 = con.prepareStatement(query2);
						     ResultSet rs2 = pstmt2.executeQuery();
						     
						     int id = 0;
						    while (rs2.next()) {
						    	String name1 = rs2.getString("ORDERNAME");
						    	if (name.equals(name1))
						    	{
					          id = rs2.getInt("ORDERID");
						    	}
						    }
						    
						  int rows = tblSelected.getRowCount(); 
						    
				         for( int i =0 ; i < rows ; i++)
				         {
								String query3 = " INSERT INTO DELIVERY (PRODUCT_ID, QUANTITY_ORDERED, ORDERID) VALUES (?,?,?);";

				         
				        		Object product = tblSelected.getModel().getValueAt(i, 0);
								Object quantity =  tblSelected.getModel().getValueAt(i, 3);

				    
				         
				         PreparedStatement pstmt3 = con.prepareStatement(query3);
				         pstmt3.setObject(1, product );
				         pstmt3.setObject(2, quantity);		
				         pstmt3.setInt(3,id);	
				         
				         pstmt3.addBatch();
				         pstmt3.executeUpdate();		
				         
				         }
					
				         
						
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					
							
					
				
					JOptionPane.showMessageDialog(null, "The creation of new order was successfull");

				
				txtproductName.setText("");
				
			}}
		});
		btncretaOrder.setBounds(254, 49, 135, 23);
		contentPane.add(btncretaOrder);
		
		tblProducts = new JTable();
		tblProducts.setModel(new DefaultTableModel(
			new Object[][] {
				{null},
			},
			new String[] {
				"amount"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tblProducts.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		tblProducts.setBounds(61, 136, 250, 115);
		contentPane.add(tblProducts);
		
		txtproductName = new JTextField();
		txtproductName.setBounds(75, 95, 104, 20);
		contentPane.add(txtproductName);
		txtproductName.setColumns(10);
		
		JLabel lblMessage = new JLabel("Order Name");
		lblMessage.setBounds(72, 70, 66, 14);
		contentPane.add(lblMessage);
		
		tblSelected = new JTable(1,1);
		tblSelected.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblSelected.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"Product Id", "New column", "New column", "New column", "A"
			}
		));
		tblSelected.setBounds(351, 136, 250, 115);
		contentPane.add(tblSelected);
		
		btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				countrow = 0;
				int row = tblProducts.getSelectedRow();
			
				
				Integer id = (Integer) tblProducts.getModel().getValueAt(row, 0);
				Object name = (String) tblProducts.getModel().getValueAt(row, 1);
				Object descreption = (String) tblProducts.getModel().getValueAt(row, 2);
				Integer price = (Integer) tblProducts.getModel().getValueAt(row, 3);
				
				
			    tblSelected.getModel().setValueAt(id, countrow, 0);
			    tblSelected.getModel().setValueAt(name, countrow, 1);
			    tblSelected.getModel().setValueAt(descreption, countrow, 2);
			    tblSelected.getModel().setValueAt(price, countrow, 3);
			    tblSelected.getModel().setValueAt( "0", countrow, 4);

			    
			    countrow = countrow +1 ;
			    
			    DefaultTableModel model = (DefaultTableModel) tblSelected.getModel();
			    model.addRow(new Object[]{"", "", "","",""});

			    
				
				

			}
		});
		btnInsert.setBounds(222, 262, 89, 23);
		contentPane.add(btnInsert);
	}
	
	
	private static void populateTable() {
		// TODO Auto-generated method stub
		
		//Connect to database and make the query
		ResultSet rs = DbConn.connectToDB(" SELECT * FROM PRODUCT ");
			
		//populate the table
		try {
			while(rs.next()) {
				tblProducts.setModel(DbUtils.resultSetToTableModel(rs));
			
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
