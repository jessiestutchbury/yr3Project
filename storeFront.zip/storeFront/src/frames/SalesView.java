package frames;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DBConn.DbConn;
import DBConn.DbUtils;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.border.BevelBorder;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.awt.Component;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Toolkit;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class SalesView extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtMgrOptions;
	private static JTextField todayTotal;
	private static JTextField txtgoal;
	private JButton btnEditTarget;
	private static Integer targetTodayID;
	private JLabel label;
	private JLabel lblTodaysTarget;
	private static JTable tblSales;
	private JScrollPane scrollPane;
	private JTextField txtSetTarget;
	private JTextField txtEditTarget;



	/**
	 * Create the frame.
	 */
	public SalesView() {
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(320, 700, 629, 356);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		int w = this.getSize().width;
        int h = this.getSize().height;
        int x = (dim.width-w)/2;
        int y = (dim.height-h)/2;

        // Move the window
        this.setLocation(x, y);
		
		JLabel header = new JLabel("Today sales");
		header.setBounds(275, 88, 153, 36);
		header.setHorizontalAlignment(SwingConstants.CENTER);
		header.setForeground(new Color(255, 255, 255));
		header.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 20));
		contentPane.add(header);
		setUndecorated(true); //removes frame outline
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 32, 629, 14);
		separator.setForeground(new Color(0, 0, 0));
		separator.setBackground(new Color(0, 0, 0));
		separator.setAlignmentX(Component.RIGHT_ALIGNMENT);
		contentPane.add(separator);
		
		txtMgrOptions = new JTextField();		
		txtMgrOptions.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Dashboard dashboard;
				try {
					dashboard = new Dashboard();
					dashboard.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
			
		});
		
		
		txtMgrOptions.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		txtMgrOptions.setEditable(false);
		txtMgrOptions.setBackground(new Color(105, 105, 105));
		txtMgrOptions.setForeground(new Color(255, 255, 255));
		txtMgrOptions.setHorizontalAlignment(SwingConstants.CENTER);
		txtMgrOptions.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtMgrOptions.setText("CLOSE");
		txtMgrOptions.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		txtMgrOptions.setBounds(447, 306, 172, 36);
		contentPane.add(txtMgrOptions);
		txtMgrOptions.setColumns(10);
		
		todayTotal = new JTextField();
		todayTotal.setBounds(455, 101, 86, 20);
		contentPane.add(todayTotal);
		todayTotal.setColumns(10);
		
		txtgoal = new JTextField();
		txtgoal.setBounds(455, 147, 86, 20);
		contentPane.add(txtgoal);
		txtgoal.setColumns(10);
		
		btnEditTarget = new JButton("Edit Target");
		btnEditTarget.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				Date date = new java.sql.Date(new java.util.Date().getTime());	
			
				
				
						
						try {
							
							int newTarget =  Integer.parseInt(txtgoal.getText());
							String query = "UPDATE SALESTARGET SET AMOUNT = ? " + " WHERE SALESTARGET_ID = '" + targetTodayID + "';";
							
							//connect with the database
							String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
					         String uName = "user";
					         String uPass = "pass";
					         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
					         Connection con = DriverManager.getConnection(host, uName, uPass);
					         
					         PreparedStatement pstmt = con.prepareStatement(query);
					         
					         pstmt.setInt(1, newTarget);
					         
					         
					         pstmt.executeUpdate();
								JOptionPane.showMessageDialog(null, "The sales target for today has been successfully been changed ");
						}

							 catch (Exception e1) {
									e1.printStackTrace();
								}
			}
		});
		btnEditTarget.setBounds(491, 226, 89, 23);
		contentPane.add(btnEditTarget);
		
		label = new JLabel("SPYROU & SONS");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 20));
		label.setBounds(22, 0, 153, 36);
		contentPane.add(label);
		
		lblTodaysTarget = new JLabel("Today's target");
		lblTodaysTarget.setHorizontalAlignment(SwingConstants.CENTER);
		lblTodaysTarget.setForeground(Color.WHITE);
		lblTodaysTarget.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 20));
		lblTodaysTarget.setBounds(275, 135, 153, 36);
		contentPane.add(lblTodaysTarget);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 88, 252, 202);
		contentPane.add(scrollPane);
		
		tblSales = new JTable();
		scrollPane.setViewportView(tblSales);
		tblSales.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Name", "Price"
			}
		));
		
		txtSetTarget = new JTextField();
		txtSetTarget.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				

				int amount =  Integer.parseInt(txtgoal.getText());
							try {
								
								boolean check = false;
								Date date1 = new java.sql.Date(new java.util.Date().getTime());		
								ResultSet rs1 = DbConn.connectToDB(" SELECT DATE FROM SALESTARGET  " );
								
								while (rs1.next())
								{
									 
									Date date = rs1.getDate("DATE");

							    	if (date.after(date1))
							    	{
							    		check = true;
							    	}
								}
									
								if (check == true  )
								{
								String query = "INSERT INTO SALESTARGET (DATE, AMOUNT ) VALUES (?,?);";
								
								
								
								 String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
								  String uName = "user";
							         String uPass = "pass";
							         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
							         Connection con = DriverManager.getConnection(host, uName, uPass);
								   
							         PreparedStatement pstmt = con.prepareStatement(query);					         
							         pstmt.setDate(1, new java.sql.Date(new java.util.Date().getTime()));			
							         pstmt.setInt(2, amount);	
							        
							         pstmt.executeUpdate();	     
							         pstmt.close();
								}
								else
								{
									JOptionPane.showMessageDialog(null, " The target for today is arleady been set. If you want to change it, enter the amount and then select the Edit target button");
								}
								
								
							}
						
							
							catch(Exception ex1) {
								System.out.println(ex1);
							}
						
						}
					});

				
			
	
		txtSetTarget.setText("SET TARGET");
		txtSetTarget.setHorizontalAlignment(SwingConstants.CENTER);
		txtSetTarget.setForeground(Color.WHITE);
		txtSetTarget.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtSetTarget.setEditable(false);
		txtSetTarget.setColumns(10);
		txtSetTarget.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		txtSetTarget.setBackground(SystemColor.controlDkShadow);
		txtSetTarget.setBounds(299, 259, 172, 36);
		contentPane.add(txtSetTarget);
		
		txtEditTarget = new JTextField();
		txtEditTarget.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Date date = new java.sql.Date(new java.util.Date().getTime());	
				
				
				
				
				try {
					
					int newTarget =  Integer.parseInt(txtgoal.getText());
					String query = "UPDATE SALESTARGET SET AMOUNT = ? " + " WHERE SALESTARGET_ID = '" + targetTodayID + "';";
					
					//connect with the database
					String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
			         String uName = "user";
			         String uPass = "pass";
			         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
			         Connection con = DriverManager.getConnection(host, uName, uPass);
			         
			         PreparedStatement pstmt = con.prepareStatement(query);
			         
			         pstmt.setInt(1, newTarget);
			         
			         
			         pstmt.executeUpdate();
						JOptionPane.showMessageDialog(null, "The sales target for today has been successfully been changed ");
				}

					 catch (Exception e1) {
							e1.printStackTrace();
						}
	}
				
			
		});
		txtEditTarget.setText("EDIT TARGET");
		txtEditTarget.setHorizontalAlignment(SwingConstants.CENTER);
		txtEditTarget.setForeground(Color.WHITE);
		txtEditTarget.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtEditTarget.setEditable(false);
		txtEditTarget.setColumns(10);
		txtEditTarget.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		txtEditTarget.setBackground(SystemColor.controlDkShadow);
		txtEditTarget.setBounds(299, 218, 172, 36);
		contentPane.add(txtEditTarget);
		
		
		
		populateTableSales();
		salesTarget();
		
		calculateTotal();
		
	}
	
	public static void calculateTotal() {
		Date date = new java.sql.Date(new java.util.Date().getTime());	
		ResultSet rs = DbConn.connectToDB("SELECT DATE, SALE_PRICE FROM SALES ");
		int total = 0;
		try {
		

			while(rs.next()) {
				Date date1 = rs.getDate("DATE");
				if (date.before(date1) )
				{
					
				}
				else {
				total = total + rs.getInt("SALE_PRICE");
				todayTotal.setText(String.valueOf(total));
				}
		}
			
	}
		catch(Exception ex1) {
			System.out.println(ex1);
		
	  
		
	}
	}
	
	
	
	public static void populateTableSales()
	{
		
		//Connect to database and make the query
		ResultSet rs = DbConn.connectToDB("SELECT PRODUCT_NAME AS 'Product', DATE AS 'Date', SALE_PRICE AS 'Price' FROM SALES");
			
		//populate the table
		try {
			while(rs.next()) {
				tblSales.setModel(DbUtils.resultSetToTableModel(rs));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	
	
	public static void salesTarget()
	{
		Date date = new java.sql.Date(new java.util.Date().getTime());	
		int target = 0;
		
		ResultSet rs = DbConn.connectToDB("SELECT SALESTARGET_ID,DATE, AMOUNT FROM SALESTARGET");
		try{
		while(rs.next()) {
			Date date1 = rs.getDate("DATE");
			
			if (date.before(date1) )
			{
				
			}
			else {
			target =  rs.getInt("AMOUNT");
			System.out.println(date1);
			txtgoal.setText(String.valueOf(target));
			targetTodayID = rs.getInt("SALESTARGET_ID") ;
			
			}
		}
		}
		catch(Exception ex1) {
			System.out.println(ex1);
		}
		
	}
}

