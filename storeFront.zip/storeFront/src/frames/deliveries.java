package frames;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

import DBConn.DbConn;
import DBConn.DbUtils;

import javax.swing.event.ChangeEvent;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class deliveries extends JFrame {

	private JPanel contentPane;
	private JTextField txtID;
	private JTable tblOrders;
	private JTable tblProducts;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
	//	EventQueue.invokeLater(new Runnable() {
		//	public void run() {
			//	try {
				//	deliveries frame = new deliveries();
				//	frame.setVisible(true);
				//} catch (Exception e) {
				//	e.printStackTrace();
				//}
		//	}
		//});
//}

	/**
	 * Create the frame.
	 */
	public deliveries() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtID = new JTextField();
		txtID.setBounds(41, 31, 86, 20);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		tblOrders = new JTable();
		tblOrders.setShowVerticalLines(false);
		tblOrders.setShowHorizontalLines(false);
		tblOrders.setShowGrid(false);
		tblOrders.setBounds(167, 34, 257, 20);
		contentPane.add(tblOrders);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
			
				if (txtID.getText() == null || txtID.getText().trim().isEmpty()  )
				{
					
					JOptionPane.showMessageDialog(null, "Enter ID to search!");

				}
				
				else {
					Integer id = Integer.parseInt(txtID.getText());
					
				
				
				try {
			
			//Connect to database and make the query
			String q = " SELECT * FROM ORDERS WHERE ORDERID = " + id + " AND CONFIRM = " + 0;
			String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
	         String uName = "user";
	         String uPass = "pass";
	         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
	         Connection con = DriverManager.getConnection(host, uName, uPass);
	         
			PreparedStatement pst = con.prepareStatement(q);
			ResultSet rs = pst.executeQuery();
			tblOrders.setModel(DbUtils.resultSetToTableModel(rs));
			//populate the table
			
				}
				
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			
				
				//Connect to database and make the query
				ResultSet rs = DbConn.connectToDB("SELECT * FROM ORDERS RIGHT JOIN DELIVERY ON ORDERS.ORDERID = DELIVERY.ORDERID WHERE ORDERS.ORDERID = " + id + " AND CONFIRM = " + 0 );
				
				//populate the table
				try {
					while(rs.next()) {
						tblProducts.setModel(DbUtils.resultSetToTableModel(rs));
					}
					
					}
				 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}//end of else
				
				}
				
			
		
		
		});
		btnSearch.setBounds(41, 62, 89, 23);
		contentPane.add(btnSearch);
		
		JButton btnConfirm = new JButton("Confirm Delivery");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Integer id = Integer.parseInt(txtID.getText());
				try {
					
                String query = "UPDATE ORDERS SET CONFIRM = ? " + " WHERE ORDERID = " + id;
				
				//connect with the database
				String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
		         String uName = "user";
		         String uPass = "pass";
		         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
		         Connection con = DriverManager.getConnection(host, uName, uPass);
		         
		         PreparedStatement pstmt = con.prepareStatement(query);
		         
		         pstmt.setInt(1, 1);
		         
		         
		         pstmt.executeUpdate();
		         
		         //clear the table when the delivery is been set to confirmed
		         DefaultTableModel dm = (DefaultTableModel)tblOrders.getModel();
		         dm.getDataVector().removeAllElements();
		         dm.fireTableDataChanged();
		         
		         //clear the table when the delivery is been set to confirmed
		         DefaultTableModel dm1 = (DefaultTableModel)tblProducts.getModel();
		         dm1.getDataVector().removeAllElements();
		         dm1.fireTableDataChanged();
			}

				 catch (Exception e1) {
						e1.printStackTrace();
					}
				txtID.setText("");
				tblProducts.clearSelection();
			}
		});
		btnConfirm.setBounds(180, 214, 111, 23);
		contentPane.add(btnConfirm);
		
		JButton btnEdit = new JButton("Edit Delivery");
		btnEdit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				
				
				
			}
		});
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = -1;
				 row = tblProducts.getSelectedRow();
				
				 		//check if the user has selected a row and sent a message
					if ( tblProducts.getSelectedRow() == -1 )
					{
						//message
						JOptionPane.showMessageDialog(null, "First select order and product, and then try to edit the products");
						
						}
					// if the user selected a row continue the edit process
					else {
				
			
				try {
					
					Object id = (String) tblProducts.getModel().getValueAt(row, 0);
					Integer product = (Integer) tblProducts.getModel().getValueAt(row, 1);
					Integer quantity_ordered = (Integer) tblProducts.getModel().getValueAt(row, 2);
				//	Object order_id = (String) tblProducts.getModel().getValueAt(row, 3);
					
					String query = "UPDATE DELIVERY SET PRODUCT_ID = ? ," + " QUANTITY = ?, "  + " WHERE DELIVERY_ID = " + id;
					
					//connect with the database
					String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
			         String uName = "user";
			         String uPass = "pass";
			         String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
			         Connection con = DriverManager.getConnection(host, uName, uPass);
			         
			         PreparedStatement pstmt = con.prepareStatement(query);
			         
			         pstmt.setInt(1,  product);
			         pstmt.setInt(2, quantity_ordered);
			         
			         pstmt.executeUpdate();
				
			}
				 catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				
			}
		});
		btnEdit.setBounds(309, 214, 104, 23);
		contentPane.add(btnEdit);
		
		tblProducts = new JTable();
		tblProducts.setBounds(167, 94, 257, 110);
		contentPane.add(tblProducts);
	}
}
