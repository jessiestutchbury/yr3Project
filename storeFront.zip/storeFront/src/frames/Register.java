package frames;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

import DBConn.DbConn;

import javax.swing.JComboBox;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextArea;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.SystemColor;
import java.awt.Toolkit;

public class Register extends JFrame {

	private JButton btnCreateAccount;
	private JButton btnEditAccount;
	private JButton btnClearanceLevelHelp;
	private JButton btnClosePanelCreateAccount;
	private JButton btnCreateNewAccount;
	private JButton btnClosePanelCreateAccount2;
	private JButton btnBackToCreateAccount;
	private JButton btnSetCredentials;
	private JButton btnClosePanelEditAccount;
	private JButton btnSetCredentials2;
	private JButton btnDeleteUser;
	private JButton btnUpdateUser;
	private JComboBox cmbUserAccess;
	private JLabel title;
	private JLabel header;
	private JLabel lblCreateAccount;
	private JLabel lblFirstName;
	private JLabel lblSurname;
	private JLabel lblEmail;
	private JLabel lblContact;
	private JLabel lblClearanceLevel;
	private JLabel lblCredentials;
	private JLabel lblUsername;
	private JLabel lblPassword;
	private JLabel lblEditAccount;
	private JLabel lblConfirmPassword;
	private JLabel lblUsername2;
	private JLabel lblPassword2;
	private JLabel lblFirstName2;
	private JLabel lblSurname2;
	private JLabel lblConfirmPassword2;
	private JPanel contentPane;
	private JPanel pnlClearanceLevelHelp;
	private JPanel pnlCreateAccount;
	private JPanel pnlCreateAccount2;
	private JPanel pnlEditAccount;
	private JPasswordField pwdPassword;
	private JPasswordField pwdConfirmPassword;
	private JPasswordField pwdPassword2;
	private JPasswordField pwdConfirmPassword2;
	private JTextArea txtAreaClearanceLevelHelp;
	private JTextField txtFirstName;
	private JTextField txtSurname;
	private JTextField txtEmail;
	private JTextField txtContact;
	private JTextField txtClose;
	private JTextField txtUsername;
	private JTextField txtUsername2;
	private JTextField txtUserID2;
	private JTextField txtFirstName2;
	private JTextField txtSurname2;
	private JTextField FirstNameSearchResult;
	private JSeparator separator;
	private JSeparator createAccountSeparator;
	private JSeparator setCredentialsSeparator;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(320, 180, 629, 356);
		contentPane = new JPanel();
		contentPane.setAlignmentX(Component.RIGHT_ALIGNMENT);
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(null);
		contentPane.setLayout(null);
		setContentPane(contentPane);
		setUndecorated(true);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		int w = this.getSize().width;
        int h = this.getSize().height;
        int x = (dim.width-w)/2;
        int y = (dim.height-h)/2;

        // Move the window
        this.setLocation(x, y);
		
        //frame header
		header = new JLabel("SPYROU & SONS");
		header.setHorizontalAlignment(SwingConstants.CENTER);
		header.setForeground(new Color(255, 255, 255));
		header.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 20));
		header.setBounds(0, 0, 180, 36);
		contentPane.add(header);
		
		separator = new JSeparator();
		separator.setForeground(Color.black);
		separator.setBackground(Color.black);
		separator.setAlignmentX(Component.RIGHT_ALIGNMENT);
		separator.setBounds(0, 33, 629, 14);
		contentPane.add(separator);
		
		//title
		title = new JLabel("USER ACCOUNT CONTROL");
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setForeground(Color.WHITE);
		title.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 20));
		title.setBounds(156, 33, 316, 45);
		contentPane.add(title);
		
		//set panels
		pnlClearanceLevelHelp = new JPanel();
		pnlClearanceLevelHelp.setBounds(350, 240, 205, 65);
		pnlClearanceLevelHelp.setBackground(new Color(105, 105, 105));
		pnlClearanceLevelHelp.setBorder(new BevelBorder(BevelBorder.RAISED, Color.black, Color.black, Color.black, Color.black));
		pnlClearanceLevelHelp.setLayout(null);
		pnlClearanceLevelHelp.setVisible(false);
		contentPane.add(pnlClearanceLevelHelp);
		
		pnlCreateAccount = new JPanel();
		pnlCreateAccount.setBounds(30, 110, 570, 240);
		pnlCreateAccount.setBackground(new Color(105,105,105));
		pnlCreateAccount.setBorder(BorderFactory.createEtchedBorder());
		pnlCreateAccount.setLayout(null);
		pnlCreateAccount.setVisible(false);
		contentPane.add(pnlCreateAccount);
		
		pnlCreateAccount2 = new JPanel();
		pnlCreateAccount2.setBounds(30, 110, 570, 240);
		pnlCreateAccount2.setBackground(new Color(105,105,105));
		pnlCreateAccount2.setBorder(BorderFactory.createEtchedBorder());
		pnlCreateAccount2.setLayout(null);
		pnlCreateAccount2.setVisible(false);
		contentPane.add(pnlCreateAccount2);
		
		pnlEditAccount = new JPanel();
		pnlEditAccount.setBounds(30, 110, 570, 240);
		pnlEditAccount.setBackground(new Color(105,105,105));
		pnlEditAccount.setBorder(BorderFactory.createEtchedBorder());
		pnlEditAccount.setLayout(null);
		pnlEditAccount.setVisible(false);
		contentPane.add(pnlEditAccount);
		
		//navigation buttons 
		btnCreateAccount = new JButton("CREATE ACCOUNT");
		btnCreateAccount.setBounds(90, 70, 165, 36);
		btnCreateAccount.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 14));
		btnCreateAccount.setForeground(Color.white);
		btnCreateAccount.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCreateAccount.setBackground(SystemColor.controlDkShadow);
		btnCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlCreateAccount.setVisible(true);
				pnlCreateAccount2.setVisible(false);
				pnlEditAccount.setVisible(false);
			}
		});
		contentPane.add(btnCreateAccount);
		
		btnEditAccount = new JButton("EDIT ACCOUNT");
		btnEditAccount.setBounds(370, 70, 165, 36);
		btnEditAccount.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 14));
		btnEditAccount.setForeground(Color.white);
		btnEditAccount.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnEditAccount.setBackground(SystemColor.controlDkShadow);
		btnEditAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlEditAccount.setVisible(true);
				pnlCreateAccount.setVisible(false);
				pnlCreateAccount2.setVisible(false);
				pnlClearanceLevelHelp.setVisible(false);
			}
		});
		contentPane.add(btnEditAccount);
		
		//panel CreateAccount contents
		//title
		lblCreateAccount = new JLabel("Create Account");
		lblCreateAccount.setFont(new Font("Yu Gothic UI", Font.BOLD, 18));
		lblCreateAccount.setForeground(Color.white);
		lblCreateAccount.setBounds(220, 5, 152, 20);
		pnlCreateAccount.add(lblCreateAccount);
		
		//close panel CreateAccount
		btnClosePanelCreateAccount = new JButton("X");
		btnClosePanelCreateAccount.setBounds(545, 5, 20, 20);
		btnClosePanelCreateAccount.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 12));
		btnClosePanelCreateAccount.setForeground(Color.white);
		btnClosePanelCreateAccount.setBackground(new Color(105, 105, 105));
		btnClosePanelCreateAccount.setBorder(BorderFactory.createLineBorder(new Color(105, 105, 105)));
		pnlCreateAccount.add(btnClosePanelCreateAccount);
		btnClosePanelCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlCreateAccount.setVisible(false);
				pnlClearanceLevelHelp.setVisible(false);
				txtFirstName.setText(null);
				txtSurname.setText(null);
				txtEmail.setText(null);
				txtContact.setText(null);
			}
		});
		
		//user personal information
		lblFirstName = new JLabel("First Name:");
		lblFirstName.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblFirstName.setBounds(30, 40, 80, 20);
		lblFirstName.setForeground(Color.white);
		pnlCreateAccount.add(lblFirstName);
		
		txtFirstName = new JTextField();
		txtFirstName.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtFirstName.setBounds(110, 40, 150, 23);
		txtFirstName.setForeground(Color.white);
		txtFirstName.setBackground(new Color(105, 105, 105));
		txtFirstName.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount.add(txtFirstName);

		lblSurname = new JLabel("Surname:");
		lblSurname.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblSurname.setBounds(300, 40, 60, 20);
		lblSurname.setForeground(Color.white);
		pnlCreateAccount.add(lblSurname);
		
		txtSurname = new JTextField();
		txtSurname.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtSurname.setBounds(370, 40, 150, 23);
		txtSurname.setForeground(Color.white);
		txtSurname.setBackground(new Color(105, 105, 105));
		txtSurname.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount.add(txtSurname);
		
		lblEmail = new JLabel("E-mail:");
		lblEmail.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblEmail.setBounds(60, 80, 50, 20);
		lblEmail.setForeground(Color.white);
		pnlCreateAccount.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtEmail.setBounds(110, 80, 150, 23);
		txtEmail.setForeground(Color.white);
		txtEmail.setBackground(new Color(105, 105, 105));
		txtEmail.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount.add(txtEmail);
		
		lblContact = new JLabel("Contact:");
		lblContact.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblContact.setBounds(305, 80, 60, 20);
		lblContact.setForeground(Color.white);
		pnlCreateAccount.add(lblContact);

		txtContact = new JTextField();
		txtContact.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtContact.setBounds(370, 80, 150, 23);
		txtContact.setForeground(Color.white);
		txtContact.setBackground(new Color(105, 105, 105));
		txtContact.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount.add(txtContact);
		
		createAccountSeparator = new JSeparator();
		createAccountSeparator.setBounds(60, 120, 450, 13);
		createAccountSeparator.setForeground(Color.black);
		pnlCreateAccount.add(createAccountSeparator);

		//user clearance level access
		lblClearanceLevel = new JLabel("Access:");
		lblClearanceLevel.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblClearanceLevel.setBounds(55, 150, 80, 20);
		lblClearanceLevel.setForeground(Color.white);
		pnlCreateAccount.add(lblClearanceLevel);
		
		String[] clearanceLevelDescriptions = new String[] {" ", "Basic User", "Management"};
		JComboBox<String> cmbUserAccess = new JComboBox<String>(clearanceLevelDescriptions);
		cmbUserAccess.setBounds(110, 150, 150, 23);
		cmbUserAccess.setForeground(Color.white);
		cmbUserAccess.setBackground(new Color(105, 105, 105));
		pnlCreateAccount.add(cmbUserAccess);
		
		txtAreaClearanceLevelHelp = new JTextArea("Select Management for user to view Manager Options pane in the system");
		txtAreaClearanceLevelHelp.setBounds(2, 2, 200, 60);
		txtAreaClearanceLevelHelp.setForeground(Color.white);
		txtAreaClearanceLevelHelp.setWrapStyleWord(true);
		txtAreaClearanceLevelHelp.setLineWrap(true);
		txtAreaClearanceLevelHelp.setEditable(false);
		txtAreaClearanceLevelHelp.setBackground(new Color(105,105,105));
		pnlClearanceLevelHelp.add(txtAreaClearanceLevelHelp);
		
		btnClearanceLevelHelp = new JButton("?");
		btnClearanceLevelHelp.setBounds(270, 150, 40, 23);
		btnClearanceLevelHelp.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 12));
		btnClearanceLevelHelp.setForeground(Color.white);
		btnClearanceLevelHelp.setBackground(new Color(105, 105, 105));
		btnClearanceLevelHelp.setBorder(BorderFactory.createLineBorder(Color.black));
		pnlCreateAccount.add(btnClearanceLevelHelp);
		btnClearanceLevelHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlClearanceLevelHelp.setVisible(true);
			}
		});
			
		//move to next stage of CreateNewAccount
		btnCreateNewAccount = new JButton("CREATE ACCOUNT");
		btnCreateNewAccount.setBounds(220, 210, 150, 23);
		btnCreateNewAccount.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 14));
		btnCreateNewAccount.setForeground(Color.white);
		btnCreateNewAccount.setBackground(new Color(105, 105, 105));
		btnCreateNewAccount.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		pnlCreateAccount.add(btnCreateNewAccount);
		btnCreateNewAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlCreateAccount2.setVisible(true);
				pnlCreateAccount.setVisible(false);
				}
		});         
		
		//panel CreateAccount2 contents
		//title
		lblCredentials = new JLabel("Set User Credentials");
		lblCredentials.setFont(new Font("Yu Gothic UI", Font.BOLD, 18));
		lblCredentials.setForeground(Color.white);
		lblCredentials.setBounds(215, 5, 170, 20);
		pnlCreateAccount2.add(lblCredentials);
				
		//close panel CreateAccount2
		btnClosePanelCreateAccount2 = new JButton("X");
		btnClosePanelCreateAccount2.setBounds(545, 5, 20, 20);
		btnClosePanelCreateAccount2.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 12));
		btnClosePanelCreateAccount2.setForeground(Color.white);
		btnClosePanelCreateAccount2.setBackground(new Color(105, 105, 105));
		btnClosePanelCreateAccount2.setBorder(BorderFactory.createLineBorder(new Color(105, 105, 105)));
		pnlCreateAccount2.add(btnClosePanelCreateAccount2);
		btnClosePanelCreateAccount2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlCreateAccount2.setVisible(false);
			}
		});
		
		//back to panel CreateAccount
		btnBackToCreateAccount = new JButton("<");
		btnBackToCreateAccount.setBounds(5, 5, 20, 20);
		btnBackToCreateAccount.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 12));
		btnBackToCreateAccount.setForeground(Color.white);
		btnBackToCreateAccount.setBackground(new Color(105, 105, 105));
		btnBackToCreateAccount.setBorder(BorderFactory.createLineBorder(new Color(105, 105, 105)));
		pnlCreateAccount2.add(btnBackToCreateAccount);
		btnBackToCreateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlCreateAccount2.setVisible(false);
				pnlCreateAccount.setVisible(true);
			}
		});
		
		//set user credentials
		lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblUsername.setBounds(180, 40, 90, 20);
		lblUsername.setForeground(Color.white);
		pnlCreateAccount2.add(lblUsername);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtUsername.setBounds(250, 40, 150, 23);
		txtUsername.setForeground(Color.white);
		txtUsername.setBackground(new Color(105, 105, 105));
		txtUsername.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount2.add(txtUsername);
		
		setCredentialsSeparator = new JSeparator();
		setCredentialsSeparator.setBounds(60, 80, 450, 13);
		setCredentialsSeparator.setForeground(Color.black);
		pnlCreateAccount2.add(setCredentialsSeparator);
		
		lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblPassword.setBounds(180, 110, 80, 20);
		lblPassword.setForeground(Color.white);
		pnlCreateAccount2.add(lblPassword);
		
		pwdPassword = new JPasswordField();
		pwdPassword.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		pwdPassword.setBounds(250, 110, 150, 23);
		pwdPassword.setForeground(Color.white);
		pwdPassword.setBackground(new Color(105, 105, 105));
		pwdPassword.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount2.add(pwdPassword);
		
		lblConfirmPassword = new JLabel("Confirm Password:");
		lblConfirmPassword.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblConfirmPassword.setBounds(120, 150, 130, 20);
		lblConfirmPassword.setForeground(Color.white);
		pnlCreateAccount2.add(lblConfirmPassword);

		pwdConfirmPassword = new JPasswordField();
		pwdConfirmPassword.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		pwdConfirmPassword.setBounds(250, 150, 150, 23);
		pwdConfirmPassword.setForeground(Color.white);
		pwdConfirmPassword.setBackground(new Color(105, 105, 105));
		pwdConfirmPassword.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlCreateAccount2.add(pwdConfirmPassword);

		//set credentials for new account and add to database
		btnSetCredentials = new JButton("SET CREDENTIALS");
		btnSetCredentials.setBounds(220, 210, 150, 23);
		btnSetCredentials.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 14));
		btnSetCredentials.setForeground(Color.white);
		btnSetCredentials.setBackground(new Color(105, 105, 105));
		btnSetCredentials.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		pnlCreateAccount2.add(btnSetCredentials);
		btnSetCredentials.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//add to database
				String firstName = txtFirstName.getText();
				String surname = txtSurname.getText();
				String email = txtEmail.getText();
				String phoneNumber = txtContact.getText();
				String username = txtUsername.getText();
				String password = pwdPassword.getText();
				
				String insertString = "INSERT INTO EMPLOYEES (FIRST_NAME, SURNAME, EMAIL, PHONE_NUMBER, USERNAME, PASSWORD) values (?,?,?,?,?,?);";
				
				try {
					String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
			        String uName = "user";
			        String uPass = "pass";
			        String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
			         
			        Connection con = DriverManager.getConnection(host, uName, uPass);
			     
			        PreparedStatement pstmt = con.prepareStatement(insertString);
			        pstmt.setString(1, firstName);
			        pstmt.setString(2, surname);
			        pstmt.setString(3, email);
			        pstmt.setString(4, phoneNumber);
			        pstmt.setString(5, username);
			        pstmt.setString(6, password);
			        
			        pstmt.executeUpdate();
 
					}
					catch(Exception ee) {
						System.out.println(ee);
					}
				
				JOptionPane.showMessageDialog(null, "User Account Created");
				pnlCreateAccount2.setVisible(false);
				txtFirstName.setText(null);
				txtSurname.setText(null);
				txtEmail.setText(null);
				txtContact.setText(null);
				txtUsername.setText(null);
				pwdPassword.setText(null);
				pwdConfirmPassword.setText(null);
			}
		});
		
		//panel EditAccount contents
		//title 
		lblEditAccount = new JLabel("Edit Account");
		lblEditAccount.setFont(new Font("Yu Gothic UI", Font.BOLD, 18));
		lblEditAccount.setForeground(Color.white);
		lblEditAccount.setBounds(230, 5, 140, 20);
		pnlEditAccount.add(lblEditAccount);
		
		//close panel EditAccount
		btnClosePanelEditAccount = new JButton("X");
		btnClosePanelEditAccount.setBounds(545, 5, 20, 20);
		btnClosePanelEditAccount.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 12));
		btnClosePanelEditAccount.setForeground(Color.white);
		btnClosePanelEditAccount.setBackground(new Color(105, 105, 105));
		btnClosePanelEditAccount.setBorder(BorderFactory.createLineBorder(new Color(105, 105, 105)));
		pnlEditAccount.add(btnClosePanelEditAccount);
		btnClosePanelEditAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pnlEditAccount.setVisible(false);
			}
		});
		
		//search for user
		lblUsername2 = new JLabel("Username:");
		lblUsername2.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblUsername2.setBounds(150, 40, 90, 20);
		lblUsername2.setForeground(Color.white);
		pnlEditAccount.add(lblUsername2);
		
		txtUsername2 = new JTextField();
		txtUsername2.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtUsername2.setBounds(230, 40, 150, 23);
		txtUsername2.setForeground(Color.white);
		txtUsername2.setBackground(new Color(105, 105, 105));
		txtUsername2.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlEditAccount.add(txtUsername2);
		
		lblFirstName2 = new JLabel("First Name:");
		lblFirstName2.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblFirstName2.setBounds(30, 70, 80, 20);
		lblFirstName2.setForeground(Color.white);
		pnlEditAccount.add(lblFirstName2);
		
		txtFirstName2 = new JTextField();
		txtFirstName2.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtFirstName2.setBounds(110, 70, 150, 23);
		txtFirstName2.setForeground(Color.white);
		txtFirstName2.setBackground(new Color(105, 105, 105));
		txtFirstName2.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlEditAccount.add(txtFirstName2);

		lblSurname2 = new JLabel("Surname:");
		lblSurname2.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblSurname2.setBounds(300, 70, 60, 20);
		lblSurname2.setForeground(Color.white);
		pnlEditAccount.add(lblSurname2);
		
		txtSurname2 = new JTextField();
		txtSurname2.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		txtSurname2.setBounds(370, 70, 150, 23);
		txtSurname2.setForeground(Color.white);
		txtSurname2.setBackground(new Color(105, 105, 105));
		txtSurname2.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pnlEditAccount.add(txtSurname2);
		
		lblPassword2 = new JLabel("Password:");
		lblPassword2.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblPassword2.setBounds(180, 140, 80, 20);
		lblPassword2.setForeground(Color.white);
		lblPassword2.setVisible(false);
		pnlEditAccount.add(lblPassword2);
		
		pwdPassword2 = new JPasswordField();
		pwdPassword2.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		pwdPassword2.setBounds(250, 140, 150, 23);
		pwdPassword2.setForeground(Color.white);
		pwdPassword2.setBackground(new Color(105, 105, 105));
		pwdPassword2.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pwdPassword2.setVisible(false);
		pnlEditAccount.add(pwdPassword2);
		
		lblConfirmPassword2 = new JLabel("Confirm Password:");
		lblConfirmPassword2.setFont(new Font("Yu Gothic UI", Font.BOLD, 14));
		lblConfirmPassword2.setBounds(120, 170, 130, 20);
		lblConfirmPassword2.setForeground(Color.white);
		lblConfirmPassword2.setVisible(false);
		pnlEditAccount.add(lblConfirmPassword2);

		pwdConfirmPassword2 = new JPasswordField();
		pwdConfirmPassword2.setFont(new Font("Yu Gothic UI", Font.PLAIN, 14));
		pwdConfirmPassword2.setBounds(250, 170, 150, 23);
		pwdConfirmPassword2.setForeground(Color.white);
		pwdConfirmPassword2.setBackground(new Color(105, 105, 105));
		pwdConfirmPassword2.setBorder(new MatteBorder(0, 0, 2, 0, new Color(205, 205, 205)));
		pwdConfirmPassword2.setVisible(false);
		pnlEditAccount.add(pwdConfirmPassword2);
				
		btnSetCredentials2 = new JButton("SET CREDENTIALS");
		btnSetCredentials2.setBounds(220, 210, 150, 23);
		btnSetCredentials2.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 14));
		btnSetCredentials2.setForeground(Color.white);
		btnSetCredentials2.setBackground(new Color(105, 105, 105));
		btnSetCredentials2.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		pnlEditAccount.add(btnSetCredentials2);
		btnSetCredentials2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//update database
				String firstName3 = txtFirstName2.getText();
				String surname3 = txtSurname2.getText();
				String username3 = txtUsername2.getText();
				String password2 = pwdPassword2.getText();;
				
				String updatePassword = "UPDATE EMPLOYEES set PASSWORD = ? " + "WHERE FIRST_NAME = ? AND SURNAME = ?;";
				
				try {
					String host = "jdbc:sqlserver://localhost;databaseName=STOREFRONT;Trusted_Connection=True";
			        String uName = "user";
			        String uPass = "pass";
			        String connectionString = "jdbc:sqlserver://localhost;Database=master;Trusted_Connection=True;";
			         
			        Connection con = DriverManager.getConnection(host, uName, uPass);
			     
			        PreparedStatement pstmt2 = con.prepareStatement(updatePassword);
			        pstmt2.setString(1, password2);
			        pstmt2.setString(2, firstName3);
			        pstmt2.setString(3, surname3);
			        
			        pstmt2.executeUpdate();
			        JOptionPane.showMessageDialog(null, "User Account Updated");
					}
					catch(Exception ee) {
						System.out.println(ee);
					}
				pnlEditAccount.setVisible(false);
				txtFirstName2.setText(null);
				txtSurname2.setText(null);
				txtUsername2.setText(null);
				pwdPassword2.setText(null);
				pwdConfirmPassword2.setText(null);
			}			
		});
		
		//delete user
		btnDeleteUser = new JButton("DELETE USER");
		btnDeleteUser.setBounds(300, 110, 140, 23);
		btnDeleteUser.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 14));
		btnDeleteUser.setForeground(Color.white);
		btnDeleteUser.setBackground(new Color(105, 105, 105));
		btnDeleteUser.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		pnlEditAccount.add(btnDeleteUser);
		btnDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//delete from database
				String firstName2 = txtFirstName2.getText();
				String surname2 = txtSurname2.getText();
				String username2 = txtUsername2.getText();
				String sql = "DELETE FROM EMPLOYEES WHERE FIRST_NAME = '" + firstName2 +"' AND SURNAME = '" + surname2 +"' OR USERNAME = '" + username2 + "';";
				DbConn.executeSQL(sql);
				
				JOptionPane.showMessageDialog(null, "User Account Deleted");
				pnlEditAccount.setVisible(false);
				txtFirstName2.setText(null);
				txtSurname2.setText(null);
				txtUsername2.setText(null);
			}
		});
		
		//update user information
		btnUpdateUser = new JButton("UPDATE USER");
		btnUpdateUser.setBounds(120, 110, 140, 23);
		btnUpdateUser.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 14));
		btnUpdateUser.setForeground(Color.white);
		btnUpdateUser.setBackground(new Color(105, 105, 105));
		btnUpdateUser.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		pnlEditAccount.add(btnUpdateUser);
		btnUpdateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblPassword2.setVisible(true);
				pwdPassword2.setVisible(true);
				lblConfirmPassword2.setVisible(true);
				pwdConfirmPassword2.setVisible(true);
			}
		});

	txtClose = new JTextField();
	txtClose.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			dispose();
			JFrame managerOptions = new ManagerOptions();
			managerOptions.setVisible(true);
		}
	});
	txtClose.setText("CLOSE");
	txtClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	txtClose.setHorizontalAlignment(SwingConstants.CENTER);
	txtClose.setForeground(Color.WHITE);
	txtClose.setFont(new Font("Tahoma", Font.BOLD, 15));
	txtClose.setEditable(false);
	txtClose.setColumns(10);
	txtClose.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
	txtClose.setBackground(SystemColor.controlDkShadow);
	txtClose.setBounds(429, 287, 165, 36);
	contentPane.add(txtClose);
}
}

